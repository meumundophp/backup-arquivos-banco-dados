<?php  @$servidor="localhost";@$usuario="root";@$senha="";@$banco="meu_banco";@$conexao=mysqli_connect($servidor,$usuario,$senha);
@$selesiona_banco= mysqli_select_db($conexao,$banco);
mysqli_set_charset($conexao,"utf8");
 ?>