<?php function logaUsuario($login,$senha){
$nomeUserADM="Usuario Provisorio";
$loginADM="administrador";
$emailADM="emailprovisorio@provisorio.com";
$senhaADM="0192023a7bbd73250516f069df18b500";	
if($login==$loginADM && md5($senha)==$senhaADM){
$return=array("nome"=>$nomeUserADM,
"login"=>$loginADM,
"email"=>$emailADM,
"senha"=>$senhaADM);
}else{$return="false";}
return $return;
}//function ?>