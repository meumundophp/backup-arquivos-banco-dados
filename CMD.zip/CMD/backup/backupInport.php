﻿<?php //segurança
session_start();
include("../AconexaoBanco/cod_permicao.txt");
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){header("location:../ERRO.html");}
///////////////////////////////////////////////////////////////////////////////////

include("../funcoes/func1.php");


@$BntFile_tmp=$_FILES['form1']['tmp_name'];
@$nomeFile=$_FILES['form1']['name'];
@$estencao=altentica_foto($nomeFile);echo $estencao;
//if($estencao!="bac"){$id="_1";}

//=======================================================================
if(@$id==true){echo $id;}else{//se dados for validos

$nomeFile="backup.zip";
$caminhoEnvia="backupExtrair/".$nomeFile;

if(file_exists($caminhoEnvia)){unlink($caminhoEnvia);}
$movelArq=move_uploaded_file($BntFile_tmp,$caminhoEnvia);

if($movelArq==true){echo"_2";}else{echo"_0";}

}//se dados for valido
//=========================================================================



?>