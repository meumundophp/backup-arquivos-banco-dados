﻿<?php //segurança
session_start();
include("../AconexaoBanco/cod_permicao.txt");
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){header("location:../ERRO.html");}
///////////////////////////////////////////////////////////////////////////////////

include("../AconexaoBanco/conexao.php");
include("../funcoes/func1.php");
include("../id/basedados.php");

//deletando fotografias do antigo banco de dados e arquivos
deleta_conteudo_pasta("../backup/dados/fotos/");
deleta_conteudo_pasta("../backup/dados/arquivos/");
//fim função que exclui tudo que tem na pasta

$nomeFile="backup.zip";
$caminhoEnvia="backupExtrair/".$nomeFile;

//segundo passo zipando arquivo
include("../ziprar/criazip.php");
$Deszipou=extrairZip($caminhoEnvia,"dados/");
if($Deszipou=="true"){unlink($caminhoEnvia);
	
//paga backup gerado	
include("dados/banco/backup.php");
//verificando se tabelas existem se existem as limpan e inssere os dados
if(@$selesiona_banco==true){
$n=-1; while($n<$at){$n=$n+1;
$limpq=mysqli_query($conexao,"TRUNCATE TABLE  `".$tables[$n]."`");	
$exe=mysqli_query($conexao,$inseri[$n]);}//while
echo"_2";}else{echo"_1";}//caso o não aja conexão com o banco

//excluindo dados de backup não necessarios depois da extração
$backup_Text="backupExtrair/backup.zip";
if(file_exists($backup_Text)){unlink($backup_Text);}
$backup_Text="dados/banco/backup.php";
if(file_exists($backup_Text)){unlink($backup_Text);}
//echo $concluilSusesso;

	
}else{echo"_0";}//caso o não consiga extrair


?>