﻿<?php 
include("../../AconexaoBanco/conexao.php");
//include("../../funcoes/cript.php");
include("../../funcoes/func1.php");
include("../../id/basedados.php");


if($selesiona_banco){//se tem banco
//algoritimo que recebe variaveis do banco e gera comando de inserção com php
$numero_Tabelas=$N_Tables;@$Papel=$Papel.'$inseri=array("';
for($n= -1; $n<$numero_Tabelas;){$selbanco="select * from ".@$tables[$n=$n+1];
@$Papel=$Papel."insert into `".'$banco'."`."."`".@$tables[$n]."`"." (";
$Colunas_numeroxx=$Colunas_numero[$n];for($n2= -1; $n2<$Colunas_numeroxx;){$colunas=@$Colunas[$n][$n2=$n2+1];
if($colunas!=""){if($n2==$Colunas_numeroxx){@$Papel=$Papel."`".$colunas."`";}else{@$Papel=$Papel."`".$colunas."`,";}}}
@$Papel=$Papel.")";@$Papel=$Papel." values";$n4=0;
for(@$exeSelBanc=mysqli_query($conexao,$selbanco); @$conteudo=mysqli_fetch_assoc($exeSelBanc);){
	
	
@$conteudo[$colunas] = str_replace("'", "",$conteudo[$colunas]);
@$conteudo[$colunas] = str_replace('"', '',$conteudo[$colunas]);
	@$conteudo[$colunas];
	
	
	
	@$Papel=$Papel." (";
for($n3= -1; $n3<$Colunas_numeroxx;){$colunas=@$Colunas[$n][$n3=$n3+1];
if($n3==$Colunas_numeroxx){@$Papel=$Papel."'".@$conteudo[$colunas]."'";}else{@$Papel=$Papel."'".@$conteudo[$colunas]."',";}	}	
$linhasTabel=mysqli_num_rows($exeSelBanc);$n4=$n4+1;if($n4==$linhasTabel){@$Papel=$Papel." )";}else{@$Papel=$Papel." ),";}	}
if($n==$N_Tables){@$Papel=$Papel.'");';}else{@$Papel=$Papel.'","';}}
//escre vendo comandos de inserção
$gravaFolha='<?php $at='.$N_Tables.'; '.$Papel.' ?>';
//funsao que abre arquivo de texto, lembrando que w é o tipo de arquivo que abre
$Arquivo=fopen("banco/backup.php","w");
//insere seu testo no arquivo
$escreve=fwrite($Arquivo,$gravaFolha);
//fecha seu arquivo
fclose($Arquivo);


//segundo passo zipando arquivo====================================================
include("../../ziprar/criazip.php");
//nome e local do backup
$urlZip="../backupDownload/backup.bac";



//------------------------------------------------------------------------------------------------------------------------------
//***aqui fas backup de arquivos fotos e imagens

//colocando todos arquivos fotos e banco em uma array para zipar os arquivos
$Sjunt=",";
$juntandoDir=diretorio_pasta_junta("banco/",$Sjunt);
$juntandoDir=$juntandoDir.diretorio_pasta_junta("arquivos/",$Sjunt);
$juntandoDir=$juntandoDir.diretorio_pasta_junta("fotos/",$Sjunt);
$files_to_zip=explode($Sjunt,$juntandoDir);


//------------------------------------------------------------------------------------------------------------------------------

if(file_exists($urlZip)){unlink($urlZip);}
@$result=create_zip($files_to_zip,$urlZip);


if($result==true){$urlBancoBac="banco/backup.php";
if(file_exists($urlBancoBac)){unlink($urlBancoBac);}	
echo"_2";}
else{echo"_1";}






}else{echo"_0";}//se não tem banco



?>