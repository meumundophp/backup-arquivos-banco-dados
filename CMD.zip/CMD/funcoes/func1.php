﻿<?php

//pegando extensão da foto
function altentica_foto($nome_foto){
$array=explode(".",$nome_foto);
$reverte=array_reverse($array);
return $reverte[0];	}//func--------------------------------------------------


function deleta_conteudo_pasta($pasta){//deleta conteudo pasta
//$pasta = "pasta_teste/";

if(is_dir($pasta)){
$diretorio = dir($pasta);

while($arquivo = $diretorio->read()){
	
if(($arquivo != '.') && ($arquivo != '..')){
unlink($pasta.$arquivo);
$retorno="true";}

}//while

$diretorio->close();}else{$retorno="false";}
return $retorno;
}//funcaodeleta conteudo da pasta--------------------------------------------------


function verifica_estenFoto($dado){//esta função so e utilisada com backup de foto
if(file_exists($dado.".".'jpg')){$re=$dado.".jpg";}
else if(file_exists($dado.".".'JPG')){$re=$dado.".JPG";}
else if(file_exists($dado.".".'jpeg')){$re=$dado.".jpeg";}
else if(file_exists($dado.".".'JPEG')){$re=$dado.".JPEG";}
else if(file_exists($dado.".".'png')){$re=$dado.".png";}
else if(file_exists($dado.".".'PNG')){$re=$dado.".PNG";}
else if(file_exists($dado.".".'GIF')){$re=$dado.".GIF";}
else if(file_exists($dado.".".'gif')){$re=$dado.".gif";}
else if(file_exists($dado.".".'bmp')){$re=$dado.".bmp";}
else if(file_exists($dado.".".'BMP')){$re=$dado.".BMP";}
else{$re=false;}
return $re;}//function--------------------------------------------------------------


function diretorio_pasta_junta($pasta,$Sjunt){//coloca todos arquivos e diretorio em array

if(is_dir($pasta)){
$diretorio = dir($pasta);
while($arquivo = $diretorio->read()){ 
if(($arquivo != '.') && ($arquivo != '..')){
	
//armasena arquivos na array
@$retorno=$retorno.$pasta.$arquivo.$Sjunt;

}//if
}//while



$diretorio->close();}else{@$retorno="";}
return @$retorno;
}//funcao pasta junta--------------------------------------------------------------

//echo diretorio_pasta_junta("../tes/",",");

?>