﻿<?php function geraCodAcesso($senha){

//if(@$dir==false){$dir="../AconexaoBanco/cod_permicao.txt";}


date_default_timezone_set('America/Sao_paulo');	
$horario=date("H:i:s");

$cod_permmicao=md5($senha.$horario);


$Grava='<?php $cod_permmicao="'.$cod_permmicao.'"; ?>';
//funsao que abre arquivo de texto, lembrando que w é o tipo de arquivo que abre
@$Arquivo=fopen("../AconexaoBanco/cod_permicao.txt","w");
//insere seu testo no arquivo
@$escreve=fwrite($Arquivo,$Grava);
//fecha seu arquivo
fclose($Arquivo);	

return $cod_permmicao;

}//function



?>