<?php 
function logandoPorFunction($login,$senha){

//logando
$dal=logaUsuario($login,$senha);

if($dal!="false"){//caso tenha dado serto
//gerando session e cod de login	
$dal['cod']=geraCodAcesso($dal['senha']);
$dal['id']=0;
$_SESSION['cmd']=$dal;
//redireciona para index
$return="<_>true";


}else{//falha na loca��o
$return="<_>false";
	
}//else deu serto

return $return;
}//function
?>