﻿<?php

function valid($val,$tip,$caracter){

if($tip=="text"){$v="";
//se é numero
if(ctype_digit($val)==false){$v=$v."V";}
//se tem todos caracter
if(strlen($val)>$caracter){$v=$v."V";}
//cofirma
if($v=="VV"){$re="true";}else{$re="false";}
}//---------------



else if($tip=="email"){$v="";

if(
preg_match('/^[^0-9][A-z0-9._%+-]+([.][A-z0-9_]+)*[@][A-z0-9_]+([.][A-z0-9_]+)*[.][A-z]{2,4}$/', $val)){$re="true";}else{$re="false";}
}//---------





else{$re="false";}	
return $re;}//valid


