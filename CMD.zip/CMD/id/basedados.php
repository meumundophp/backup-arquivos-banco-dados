﻿<?php $X=-1; $Y=-1;//para iniciar contagem apartir do zero

//exemplo de tabela//////////////////////////////////////////////////////////////
$tables[$X=$X+1]="login";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_login";$Colunas_tipo[$X][$Y]="INT NOT NULL AUTO_INCREMENT PRIMARY KEY";//declarando nome da coluna e tipo chave primaria
$Colunas[$X][$Y=$Y+1]="email";$Colunas_tipo[$X][$Y]="varchar(270) NOT NULL";//volor de inserção tipo texto
$Colunas[$X][$Y=$Y+1]="senha";$Colunas_tipo[$X][$Y]="varchar(270) NOT NULL";//letras
$Colunas[$X][$Y=$Y+1]="tipo";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela
//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="dados";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_login";$Colunas_tipo[$X][$Y]="INT NOT NULL";//declarando nome da coluna e tipo chave primaria
$Colunas[$X][$Y=$Y+1]="nome";$Colunas_tipo[$X][$Y]="varchar(270) NOT NULL";//volor de inserção tipo texto
$Colunas[$X][$Y=$Y+1]="animversario";$Colunas_tipo[$X][$Y]="date NOT NULL";//data
$Colunas[$X][$Y=$Y+1]="sexo";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="setor";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela
//////////////////////////////////////////////////////////////////////////////////
/*$tables[$X=$X+1]="permicoes";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_login";$Colunas_tipo[$X][$Y]="INT NOT NULL";//declarando nome da coluna e tipo chave primaria
$Colunas[$X][$Y=$Y+1]="excluir";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="editar";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="visualisar";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="pagina";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela

//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="carcassa";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_carcassa";$Colunas_tipo[$X][$Y]="INT NOT NULL AUTO_INCREMENT PRIMARY KEY";
$Colunas[$X][$Y=$Y+1]="camara";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="trilho";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="fx";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="quantia";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="estado";$Colunas_tipo[$X][$Y]="int NOT NULL";//0=boa 1=estragada 2=ne
$Colunas[$X][$Y=$Y+1]="id_relatorio";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela*/



//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="relatorio";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_relatorio";$Colunas_tipo[$X][$Y]="INT NOT NULL AUTO_INCREMENT PRIMARY KEY";
$Colunas[$X][$Y=$Y+1]="data_relatorio";$Colunas_tipo[$X][$Y]="date NOT NULL";
$Colunas[$X][$Y=$Y+1]="hora";$Colunas_tipo[$X][$Y]="time NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela
//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="carcassa";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_relatorio";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="registro";$Colunas_tipo[$X][$Y]="text NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela
/*
//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="total_fx";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_relatorio";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="total_fx";$Colunas_tipo[$X][$Y]="text NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela
//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="condenados";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_relatorio";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="condenados_lot";$Colunas_tipo[$X][$Y]="text NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela
*/



//////////////////////////////////////////////////////////////////////////////////
$tables[$X=$X+1]="registro";//nome da tabela
$Colunas[$X][$Y=$Y+1]="id_registro";$Colunas_tipo[$X][$Y]="INT NOT NULL AUTO_INCREMENT PRIMARY KEY";
$Colunas[$X][$Y=$Y+1]="tabela";$Colunas_tipo[$X][$Y]="int NOT NULL";//numero tabela
$Colunas[$X][$Y=$Y+1]="id_tab";$Colunas_tipo[$X][$Y]="int NOT NULL";//cod da tab principal
$Colunas[$X][$Y=$Y+1]="tipo";$Colunas_tipo[$X][$Y]="int NOT NULL";// 1=cad 2=edito 3=excluiu cadastro excluil modificou logou sail
$Colunas[$X][$Y=$Y+1]="id_login";$Colunas_tipo[$X][$Y]="int NOT NULL";
$Colunas[$X][$Y=$Y+1]="data";$Colunas_tipo[$X][$Y]="date NOT NULL";
$Colunas[$X][$Y=$Y+1]="hora";$Colunas_tipo[$X][$Y]="time NOT NULL";
$Colunas_numero[$X]=$Y; $Y=-1;//contador de colunas e das tabela

//contagen de tabelas
$N_Tables=$X; ?>