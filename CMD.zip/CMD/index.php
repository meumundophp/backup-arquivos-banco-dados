﻿<?php 
session_start();
include("AconexaoBanco/conexao.php");
include("AconexaoBanco/cod_permicao.txt");
include("id/definicao.txt");
//recebendo paginamento
@$pg=$_GET['pg'];

///////////////////////////////////////////////////////////////////////////////////
//verificando login
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){//caso não estege logado----------
$pg="l";
}else{//caso estege logado-------------------------------------------------------

if(@$selesiona_banco==false && $pg!="l"){//caso não selecione banco
$pg=2;
$Msg_List="<span style='color:C00;'>'Erro!' </span>Não conseguimos identificar o banco “faça uma nova conexão para acessar o sistema por completo”";}


}//else--------------------------------------------------------------------------


///////////////////////////////////////////////////////////////////////////////////
//definindo likes da pagina
if(@$linkReturn!=""){$linkBntVoltar="../".$linkReturn;}
else{$linkBntVoltar="index.php?pg=l";}

$linkBntAtualisar="index.php";
$linkBntLogin="index.php?pg=l";

///////////////////////////////////////////////////////////////////////////////////
//verificando folha
if($pg==""){//folha backup
$include="paineishttp/adm/backupEdit.php";
//marca pagina
$S1="S";
}//if

//--------------------------------------------------------------------------------	
else if($pg==2){//folha backup
$include="paineishttp/adm/conexaobanco.php";
//marca pagina
$S2="S";
}//if

//--------------------------------------------------------------------------------
else if($pg==3){//folha backup
$include="paineishttp/adm/CadastroAdmLogado.php";
//marca pagina
$S3="S";
}//if

//--------------------------------------------------------------------------------
else if($pg=="l"){//folha login
$include="paineishttp/login.php";
//retira menu não acessiveis esistente
$falseMenu="false";
}//if

//////////////////////////////////////////////////////////////////////////////////


?>
<html lang="pt-br">
<head>
<meta charset="utf-8">

<meta name="theme-color" content="#333"><!--coloração no celular-->
<meta name="viewport" content="width=device-width, initial-scale=1.0"><!--desaine responsivo-->

<!--local de inserção de css inserido -->
<link type="text/css" href="css/desaine.css" rel="stylesheet" />
<link type="text/css" href="css/responcivo.css" rel="stylesheet" />



<title>Siet</title>
<script src="java/JqueryFlutu.js"></script>
<script src="java/ajax.js"></script>
<script src="java/func.js"></script>



</head>

<body>

<div id="topo">
<div id="alinhamento">

<?php if(@$falseMenu!="false"){?>
<a href="<?php echo $linkBntLogin; ?>" target="_self">
<div id="imgLogin">  </div></a>
<a href="<?php echo $linkBntVoltar; ?>" target="_self">
<div id="imgReturn">  </div></a><?php } ?>
<a href="<?php echo $linkBntAtualisar; ?>" target="_self">
<h1 class="NomeVersao">CMD 1.2</h1></a>

<div id="rodapeinvisivel"></div>
<?php if(@$falseMenu!="false"){?>
<a href="index.php" target="_self" class="LinkOculto">
<div class="TresBnt" id="TresBnt<?php echo @$S1; ?>">
<p class="LetraTresBnt" id="LetraTresBnt<?php echo @$S1; ?>">BACKUP</p>
</div></a><!--TresBnt-->
<a href="index.php?pg=2" target="_self" class="LinkOculto">
<div class="TresBnt" id="TresBnt<?php echo @$S2; ?>">
<p class="LetraTresBnt" id="LetraTresBnt<?php echo @$S2; ?>">BANCO</p>
</div></a><!--TresBnt-->
<a href="index.php?pg=3" target="_self" class="LinkOculto">
<div class="TresBnt" id="TresBnt<?php echo @$S3; ?>">
<p class="LetraTresBnt" id="LetraTresBnt<?php echo @$S3; ?>">CONTA</p>
</div></a><!--TresBnt-->
<div id="rodapeinvisivel"></div>
<?php }//if menu?>
</div><!--alinhamento-->
</div><!--topo-->


<div class="corpo">

<?php include($include); ?>

</div><!--corpo-->






</body>
</html>