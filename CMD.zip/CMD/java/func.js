$(window).ready(function(){
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////						 
window.confPainelBanco = function(){//conf banco
$("#ConectBanco").submit(function(){
//recebendo valores
var dado1=$("#val_1").attr("value");
var dado2=$("#val_2").attr("value");
var dado3=$("#val_3").attr("value");
var dado4=$("#val_4").attr("value");


//enquanto o ajax fas aquisi��o mostra img de carregamento
$("#painel_enviacao").html("<p><img src='icon/carrega.gif'> Aguarde...</p>");//montra carrega
$(".nomeCampTxt").css("color","#666");


$.ajax({
url: 'operacao/bancoGera.php?dal='+dado1+'<_>'+dado2+'<_>'+dado3+'<_>'+dado4,
success: function(data) {//se obter resposta do servidor
var data=data.split("<_>");//quebra variavel de retorno
$(".BnteditCad").css("display","block");//mostrabnt
$("#painel_enviacao").html("");//limpa barra de carregamento
if(data[1]<5){document.getElementById("val_"+data[1]).focus();
$("#txt_"+data[1]).css("color","#F00");}
else if(data[1]==0){
$("#painel_enviacao").html("<p><span style='color:#f00;'>Erro no servidor</span> 'verifique sua conex�o'</p>");//caso haja erro no servidor
$("#bolaConect").attr("style","background-color:#CCC;");
}else{ $("#painel_enviacao").html("<p>'Conex�o estabelecida com sucesso'</p>");
$("#Mgg_sitema").html("");
$("#bolaConect").attr("style","background-color:#0C0;");}//else
}//success resposta do servidor

});//ajax

return false;
});//click
}//configura��o painel banco---------------------------------------------------------------------------------------------------------------

//java funcoes backup////////////////////////////////////////////////////////////////////////////////////////



window.verifica_backup = function(){//verifica se arquivo de backup existe--------------------------
//oculta todos arquivos de backup
$(".imgbacOpeBacPai,.TXTbacOpePaiArq,.menuBack1,.menuBack2").css("display","none");
//mostra carregando
$("#CarregaArquivoBackup").html('<img src="icon/carrega.gif" />verificando backup...');

$.ajax({
url: 'operacao/backup/verificaArquivo.php',
success: function(data) {//se obter resposta do servidor
$("#CarregaArquivoBackup").html('');
var data=data.split("_");//quebra variavel de retorno
var data1=data[1].split("<");
var data2=data[2].split("<");

if(data1[0]==1){$("#imgbacOpeBacPaiID1,#TXTbacOpePaiArqID1,.menuBack1").css("display","block");
$("#TXTbacOpePaiArqID1").html("Data: "+data1[1]);}
else{$("#imgbacOpeBacPaiID1,#TXTbacOpePaiArqID1,.menuBack1").css("display","none");}

if(data2[0]==1){$("#imgbacOpeBacPaiID2,#TXTbacOpePaiArqID2,.menuBack2").css("display","block");
$("#TXTbacOpePaiArqID2").html("Data: "+data2[1]);}
else{$("#imgbacOpeBacPaiID2,#TXTbacOpePaiArqID2,.menuBack2").css("display","none");}

}//success resposta do servidor

});//ajax
	
}//verifica se backup exixste--------------------------------------------------------------
						   
						   
						  
						   
//opera��es//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


window.envia_arquivo_backup = function(){//backup envia----------------------------------------
$('.formularioBackuo').ajaxForm({//uploade--------------------------------------------
uploadProgress: function(event, position, total, percentComplete) { 
$('#BarraPercento').attr('style','width:'+percentComplete+'%;');//gera barra progresso
//$('#BarraPercento').style('width','50%');
$("#MadUpload").html("Enviando Arquivo "+percentComplete+"%");
},
success: function(data) {$('#BarraPercento').attr('style','width:0%;');//gera barra progresso
var data=data.split("_");
if(data[1]==1){//arquivo invalido
$("#MadUpload").html("Arquivo invalido");
}else if(data[1]==2){//se deu serto
$("#MadUpload").html("Arquivo enviado com sucesso");
$(".formularioBackuo").css("display","none");
$(".modalSome").css("display","block");
verifica_backup();
}else{//arquivo corrompido
$("#MadUpload").html("o arquivo foi corrompido");	
}//fim if else

}//fim sucesso   
         
});//upload-------------------------------------------------------------
}//backup envia---------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

window.cancela_painel = function(){//cancela_painel
$(".BnteditCad3").click(function(){
$(".modalSome").css("display","block");
$(".formularioBackuo,.menuImgBackupConf").css("display","none");
});//click
}//cancela_painel
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.chama_painel_dentro_painel = function(){//painel dentro painel
$(".listaOpeBacPai,.imgbacOpeBacPai,.TXTbacOpePaiArq").click(function(){
//recebe variaveis																	  
var opera=$(this).attr("opera");					 

if(opera=="1"){//fasendo backup------------------------------------

//mostra carregando
$("#CarregaArquivoBackup").html('<img src="icon/carrega.gif" />atualisando backup...');

$.ajax({//-------------------------------------
url: 'backup/dados/backupFas.php',
success: function(data) {//se obter resposta do servidor
$("#CarregaArquivoBackup").html('');
var data=data.split("_");//quebra variavel de retorno
if(data[1]=="1"){//se n�o esiste banco
$("#CarregaArquivoBackup").html('n�o existe conex�o com o banco');
}else if(data[1]=="2"){//se deu serto
verifica_backup();
}else{//erro ao compilar
$("#CarregaArquivoBackup").html('n�o foi pociveu compilar');	
}//fim else

}//success resposta do servidor

});//ajax-----------------------------------

/*
}else if(opera=="2"){//mostra menu 1-------------------------------
$(".modalSome").css("display","none");
$("#menuImgBackupConf_1").css("display","block");*/
}else if(opera=="3"){//mostra upload-------------------------------
$(".modalSome").css("display","none");
$(".formularioBackuo").css("display","block");
}/*else if(opera=="4"){//mostra menu 1-------------------------------
$(".modalSome").css("display","none");
$("#menuImgBackupConf_2").css("display","block");
}//fim else--------------------------------------------------------
*/					 
});	//click	
}//painel dentro painel

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

window.operacoes_menulisata = function(){//opera��es menu lista
$(".listeMenuBackConf").click(function(){
var numero=$(this).attr("numero");
var httpUrl="";
if(numero==5){httpUrl="backup/backupInsere.php";}
else{httpUrl="operacao/backup/operacao.php?num="+numero;}

if(numero==3){location.href="backup/backupDownload/backup.bac";}
else{//se for url
//mostra carregando
$("#CarregaArquivoBackup").html('<img src="icon/carrega.gif" />Aguarde...');	
$(".menuImgBackupConf").css("display","none");
$(".modalSome").css("display","block");

$.ajax({
url: httpUrl,
success: function(data) {//se obter resposta do servidor

verifica_backup();

}//success resposta do servidor
});//ajax


	
}//else


});//click
}//opera��es menu lista


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
window.efetivandoLogin = function(){//enviando daods de login
$("#LoginCMD").submit(function(){
//recebendo valores
var dado1=$("#val_1").attr("value");
var dado2=$("#val_2").attr("value");



//enquanto o ajax fas aquisi��o mostra img de carregamento
$("#painel_enviacao").html("<p><img src='icon/carrega.gif'> Aguarde...</p>");//montra carrega
$(".nomeCampTxt").css("color","#666");


$.ajax({
url: 'operacao/logando.php?dal='+dado1+'<_>'+dado2,
success: function(data) {//se obter resposta do servidor
var data=data.split("<_>");//quebra variavel de retorno
if(data[1]=="false"){$("#painel_enviacao").html("<p><span style='color:#f00;'>Erro no servidor</span> 'verifique seus dados'</p>");//caso haja erro no servidor
}else{location.href="index.php";}//se deu serto

}//success resposta do servidor

});//ajax

return false;
});//click
}//functin
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
});//ready