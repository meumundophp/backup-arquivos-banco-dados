﻿<?php //segurança
session_start();
include("../../AconexaoBanco/cod_permicao.txt");
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){header("location:../../ERRO.html");}
///////////////////////////////////////////////////////////////////////////////////


@$numero=$_GET['num'];


if($numero==4){//numero2--------------------------------------
//removendo arquivo de backup
if(file_exists("../../backup/backupExtrair/backup.zip")){$deleta=unlink("../../backup/backupExtrair/backup.zip");}

if(@$deleta==true){echo"_1";}else{echo"_0";}
}//numero2----------------------------------------------------

if($numero==1){//numero4--------------------------------------
//removendo arquivo de backup
if(file_exists("../../backup/backupDownload/backup.bac")){$deleta=unlink("../../backup/backupDownload/backup.bac");}

if(@$deleta==true){echo"_1";}else{echo"_0";}
}//numero4----------------------------------------------------

if($numero==2){//numero5--------------------------------------
//movendo arquivo de lugar
$arquivo_antigo="../../backup/backupDownload/backup.bac";
$arquivo_novo="../../backup/backupDownload/backup.zip";
if(file_exists($arquivo_antigo)){
$renomeia=rename($arquivo_antigo, $arquivo_novo);	
if($renomeia==true){$copia=copy($arquivo_novo, "../../backup/backupExtrair/backup.zip");}//se renomeia
if($copia==true){$deleta=unlink($arquivo_novo);}//se copia
}//se arquivo existe
if(@$deleta==true){echo"_1";}else{echo"_0";}
}//numero5----------------------------------------------------
?>