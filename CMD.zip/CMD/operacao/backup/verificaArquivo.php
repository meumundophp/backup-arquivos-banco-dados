﻿<?php //segurança
session_start();
include("../../AconexaoBanco/cod_permicao.txt");
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){header("location:../../ERRO.html");}
///////////////////////////////////////////////////////////////////////////////////


//verificando
date_default_timezone_set('America/Sao_paulo');	
@$Upoad=file_exists("../../backup/backupExtrair/backup.zip");
@$dataUP= date ("d/m/Y H:i:s.", filemtime("../../backup/backupExtrair/backup.zip"));

@$Download=file_exists("../../backup/backupDownload/backup.bac");
@$dataDO= date ("d/m/Y H:i:s", filemtime("../../backup/backupDownload/backup.bac")); 

if($Upoad==true){echo"_1<".$dataUP;}else{echo"_0<";}
if($Download==true){echo"_1<".$dataDO;}else{echo"_0<";}


?>