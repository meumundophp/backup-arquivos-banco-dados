﻿<?php //segurança
session_start();
include("../AconexaoBanco/cod_permicao.txt");
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){header("location:../ERRO.html");}
///////////////////////////////////////////////////////////////////////////////////

include("../funcoes/validForm.php");
include("../funcoes/func1.php");

//recebendo variaveis
@$dal=explode("<_>",$_GET['dal']);



//validando campos++++++++++++++++++++++++++
if(valid($dal[0],"text","2")=="false"){echo"<_>1";}
else if(valid($dal[1],"text","2")=="false"){echo"<_>2";}
else if(valid($dal[2],"text","2")=="false"){echo"<_>3";}
else{
	
$servidor=$dal[0];
$usuario=$dal[1];
$banco=$dal[2];
$senha=$dal[3];


//vereficando se banco ja esiste
@$conexao=mysqli_connect($servidor,$usuario,$senha);// or die(mysql_error());
@$selesiona_banco=mysqli_select_db($conexao,$banco);
//verificando se conecta
if($conexao){
if($selesiona_banco){mysqli_query($conexao,"DROP DATABASE $banco");}
@$com="CREATE DATABASE `$banco` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin";
@$exeCom=mysqli_query($conexao,$com);
@$ERRO1=mysqli_error();
//gravando nova conexão
@$Grava='<?php  '.
'@$servidor="'.$servidor.'";'.
'@$usuario="'.$usuario.'";'.
'@$senha="'.$senha.'";'.
'@$banco="'.$banco.'";'.
'@$conexao=mysqli_connect($servidor,$usuario,$senha);
@$selesiona_banco= mysqli_select_db($conexao,$banco);
mysqli_set_charset($conexao,"utf8");'.'
 ?>';
//funsao que abre arquivo de texto, lembrando que w é o tipo de arquivo que abre
@$Arquivo=fopen("../AconexaoBanco/conexao.php","w");
//insere seu testo no arquivo
@$escreve=fwrite($Arquivo,$Grava);
//fecha seu arquivo
fclose($Arquivo);


//se conecta++++++++++++++++++++++++++++++++++++++++++++++++
$codValidaPagina_banco="501001000";
include("../id/basedados.php");
//algoritimo que deleta tabelas e cria novas no lugar
$value=-1;while($value<$N_Tables){$value=$value+1;
$Seleciona="select * from '".$tables[$value]."'"; $exequery=mysqli_query($conexao,$Seleciona);
if($exequery){$Drop="drop table ".$tables[$value].""; $exeTrun=mysqli_query($conexao,$Drop);}
$tableCria="CREATE TABLE  `".$banco."`.`".$tables[$value]."` (";
$value2=-1;while($value2<$Colunas_numero[$value]){$value2=$value2+1;														
if($value2==$Colunas_numero[$value]){
$tableCria=$tableCria."`".$Colunas[$value][$value2]."` ".$Colunas_tipo[$value][$value2]." ";}else{															
$tableCria=$tableCria."`".$Colunas[$value][$value2]."` ".$Colunas_tipo[$value][$value2]." , ";}
}$tableCria=$tableCria.") ENGINE = INNODB ";
$intru=mysqli_query($conexao,$tableCria);
$ERRO2=mysqli_error();}//while


//deletando fotografias do antigo banco de dados-------------------------
deleta_conteudo_pasta("../backup/dados/fotos/");
deleta_conteudo_pasta("../backup/dados/arquivos/");
//fim função que exclui tudo que tem na pasta

if($ERRO1==false && $ERRO2==false){echo"_5";}
else{echo"_0";}


}//se conecta
else{echo"_0";}






}//else se deu serto

















?>