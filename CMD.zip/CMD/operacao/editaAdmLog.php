﻿<?php //segurança
session_start();
include("../AconexaoBanco/cod_permicao.txt");
if(@$cod_permmicao!= @$_SESSION['cmd']['cod']){header("location:../ERRO.html");}
///////////////////////////////////////////////////////////////////////////////////

include("../funcoes/validForm.php");

@$dal=explode("<_>",$_GET['dal']);


//validando campos++++++++++++++++++++++++++
if(valid($dal[0],"text","7")=="false"){echo"<_>1";}
else if(valid($dal[1],"text","7")=="false"){echo"<_>2";}
else if(valid($dal[2],"email","")=="false"){echo"<_>3";}
else if(valid($dal[3],"text","5")=="false"){echo"<_>4";}
else{

//cripitogrfa senha
$criptSenha=md5($dal[3]);
	
//gravando conteudo no sistema
//echo "<_>5";	
$Grava='<?php function logaUsuario($login,$senha){
$nomeUserADM="'.$dal[0].'";
$loginADM="'.$dal[1].'";
$emailADM="'.$dal[2].'";
$senhaADM="'.$criptSenha.'";	
if($login==$loginADM && md5($senha)==$senhaADM){
$return=array("nome"=>$nomeUserADM,
"login"=>$loginADM,
"email"=>$emailADM,
"senha"=>$senhaADM);
}else{$return="false";}
return $return;
}//function ?>';
	
	
	
	
//funsao que abre arquivo de texto, lembrando que w é o tipo de arquivo que abre
@$Arquivo=fopen("../AconexaoBanco/dadosADM.php","w");
//insere seu testo no arquivo
@$escreve=fwrite($Arquivo,$Grava);
//fecha seu arquivo
fclose($Arquivo);	
	
//gerando laço de session	
@$_SESSION['cmd']['nome']=$dal[0];
@$_SESSION['cmd']['login']=$dal[1];
@$_SESSION['cmd']['email']=$dal[2];
@$_SESSION['cmd']['senha']=$criptSenha;
	
	
if($escreve==true){echo"<_>serto";}else{echo"<_>erro";}	
}//else senão tiver erro
?>