﻿<?php session_start(); 
include("../AconexaoBanco/dadosADM.php");
include("../funcoes/geraCodPerm.php");
include("../funcoes/logando.php");

//recebe variavel
@$dal=$_GET['dal'];
$dal=explode("<_>",$dal);

//retorna em true ou false
echo logandoPorFunction($dal[0],$dal[1]);
?>