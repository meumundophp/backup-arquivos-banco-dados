<?php session_start();
//include("../funcao/func.php");
include("../AconexaoBanco/conexao.php");
include("../AconexaoBanco/dadosADM.php");
include("../funcoes/geraCodPerm.php");
include("../funcoes/logando.php");
//////////////////////////////////////////////////////////////////////////////////////
//pegando dados
@$login=$_POST['login'];
@$senha=$_POST['senha'];
@$senha2=$_POST['senha2'];

///////////////////////////////////////////////////////////////////////////////////
if(@$_POST['id']=="ed"){//edicao
//verificando se esta tudo preenchido


if($login==""){echo'<_>false';}
else if($senha==""){echo'<_>false';}
else if($senha2!=$senha){echo'<_>false';}
else{//edita suario

mysqli_query($conexao,"update login set email='".$login."',senha='".md5($senha)."' where id_login='". @$_SESSION['cmd']['id']."' ");
echo'<_>true';
$_SESSION['cmd']="";
}//else editando usuario


}else{//login
/////////////////////////////////////////////////////////////////////////////////////
if(logandoPorFunction($login,$senha)=="<_>true"){//logando of bd
echo"<_>true";
//------------------------------------------------------------------
}else{//logando bd

$sql=mysqli_query($conexao,"select * from login where email='".$login."' and senha='".md5($senha)."' ");
$dao=mysqli_fetch_assoc($sql);
$linhas=mysqli_num_rows($sql);

if($linhas==1){ @$_SESSION['cmd']=array("cod"=>"true",
"id"=>$dao['id_login'],
"nome"=>'',
"login"=>$dao['email'],
"email"=>$dao['email'],
"senha"=>$dao['senha'],
"tipo"=>$dao['tipo']);}//linhas

if( @$dao['id_login']!=""){echo"<_>true";}else{echo"<_>false";}

}//else login bd
///////////////////////////////////////////////////////////////////////////////////


}//esle logar


?>