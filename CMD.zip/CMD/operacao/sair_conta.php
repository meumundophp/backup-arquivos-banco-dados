﻿<?php session_start();
include("../id/definicao.txt");

//desvinculando lasso de session
@$_SESSION[$nomelassoSession]="";
@$_SESSION['cmd']="";

//enviando para pagina de saida
if(@$linkSaiConta==""){$urlR="../index.php";}
else{
//joga fora da pasta cmd e pega a url da pagina registrada
$urlR="../../".$linkSaiConta;
}//else

//enviando
header("location:".$urlR);
?>