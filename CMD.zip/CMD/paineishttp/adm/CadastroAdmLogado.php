﻿<script type="text/javascript">$(document).ready(function(){
												  														  
$(".BnteditCad4").click(function(){
//recebendo valores
var dado1=$("#val_1").attr("value");
var dado2=$("#val_2").attr("value");
var dado3=$("#val_3").attr("value");
var dado4=$("#val_4").attr("value");


//enquanto o ajax fas aquisição mostra img de carregamento
$(".nomeCampTxt").css("color","#333");
$("#painel_enviacao").html("<p><img src='icon/carrega.gif'> Aguarde...</p>");//montra carrega



$.ajax({
url: 'operacao/editaAdmLog.php?dal='+dado1+'<_>'+dado2+'<_>'+dado3+'<_>'+dado4,
success: function(data) {//se obter resposta do servidor
var data=data.split("<_>");//quebra variavel de retorno
$(".BnteditCad").css("display","block");//mostrabnt
$("#painel_enviacao").html("");//limpa barra de carregamento
if(data[1]<5){document.getElementById("val_"+data[1]).focus();
$("#txt_"+data[1]).css("color","#F00");}
else if(data[1]==5){
$("#painel_enviacao").html("<p><span style='color:#f00;'>Erro no servidor</span> 'verifique sua conexão'</p>");//caso haja erro no servidor
}else{ 
$("#painel_enviacao").html("<p><span style='color:#000;'>OK</span> 'Edição efetivada com sucesso'</p>");//caso haja erro no servidor
}//else
}//success resposta do servidor

});//ajax


});//click


//fecha painel
//ClosehttpPaineis(".BnteditCad");

});//ready
</script>
<div id="CampNomePadrao">
<div class="imgNomePg" id="imgNomePg3"></div>
<p class="TxtNomePg">MINHA CONTA CMD</p>
<div id="rodapeinvisivel"></div>
</div><!--CampNomePadrao-->


<div id="CentroFormConect">
<div id="txt_1" class="nomeCampTxt">Nome completo</div><!-- nomeCampTxt -->
<input id="val_1" type="text" class="TxtIput" value="<?php echo @$_SESSION['cmd']['nome']; ?>" / >
<div id="txt_2" class="nomeCampTxt">Login</div><!-- nomeCampTxt -->
<input id="val_2" type="text" class="TxtIput" value="<?php echo @$_SESSION['cmd']['login']; ?>" />
<div id="txt_3" class="nomeCampTxt">E-M@il</div><!-- nomeCampTxt -->
<input id="val_3" type="text" class="TxtIput" value="<?php echo @$_SESSION['cmd']['email']; ?>" />
<div id="txt_4" class="nomeCampTxt">Senha de acesso</div><!-- nomeCampTxt -->
<input id="val_4" type="password" class="TxtIput" value="" />
<div id="painel_enviacao"></div><!-- painel_enviacao -->
</div><!-- CentroFormConect -->

<input type="button" class="BnteditCad4" value="EDITAR" />








