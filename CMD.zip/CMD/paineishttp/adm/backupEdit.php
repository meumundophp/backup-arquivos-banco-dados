﻿<script type="text/javascript">
$(document).ready(function(){
cancela_painel();
envia_arquivo_backup();
chama_painel_dentro_painel();
operacoes_menulisata();
verifica_backup();
});//ready
</script>

<div id="CampNomePadrao">
<div class="imgNomePg" id="imgNomePg1"></div>
<p class="TxtNomePg">OPERAÇÕES DE BACKUP</p>
<div id="rodapeinvisivel"></div>
</div><!--CampNomePadrao-->

<div id="CentroFormConect2" class="modalSome">

<div id="CarregaArquivoBackup"></div>

<div class="listaOpeBacPai" opera="1">
<div class="imgOpeBacPai" id="imgOpeBacPai1"></div>
<div id="textOpeBacPai">Atualisar Backup</div>
<div id="rodapeinvisivel"></div>
</div><!--listaOpeBacPai" -->

<div id="CampoBacOpePail">

<div class="imgbacOpeBacPai" id="imgbacOpeBacPaiID2" opera="2"></div>
<p class="TXTbacOpePaiArq" id="TXTbacOpePaiArqID2" opera="2">backup.bac</p>


<div id="rodapeinvisivel" class="menuBack2">
<div class="listeMenuBackConf" numero="1">
Excluir
</div><!-- listeMenuBackConf -->
<div class="listeMenuBackConf" numero="2">
Transferir para upload
</div><!-- listeMenuBackConf -->
<div class="listeMenuBackConf" numero="3">
Download
</div><!-- listeMenuBackConf -->
</div><!--rodapeinvisivel-->


<div id="httpOpeBacPai">backup/backupDownload</div>
</div><!-- CampoBacOpePail -->


<div class="listaOpeBacPai" opera="3">
<div class="imgOpeBacPai" id="imgOpeBacPai2"></div>
<div id="textOpeBacPai">Anexar arquivo</div>
<div id="rodapeinvisivel"></div>
</div><!--listaOpeBacPai" -->

<div id="CampoBacOpePail">

<div class="imgbacOpeBacPai" id="imgbacOpeBacPaiID1" opera="4"></div>
<p class="TXTbacOpePaiArq" id="TXTbacOpePaiArqID1" opera="4">backup.bac</p>

<div id="rodapeinvisivel" class="menuBack1">
<div class="listeMenuBackConf" numero="4">
Excluir
</div><!-- listeMenuBackConf -->
<div class="listeMenuBackConf" numero="5">
Aplicar ao sistema
</div><!-- listeMenuBackConf -->
</div><!--rodapeinvisivel-->

<div id="httpOpeBacPai">backup/backupExtrair</div>
</div><!-- CampoBacOpePail -->


</div><!-- CentroFormConect2 -->
<!--/////////////////////////////////////////////////////////////////////////////////////////////////////-->
  

<form class="formularioBackuo" method="post" action="backup/backupInport.php" enctype="multipart/form-data">
<div id="CentroFormConect2">
<input type="file" name="form1" class="uplodBackup" id="uplodBackup" accept=".bac" value=""><br/>
<div id="MadUpload">Porcentagen 0%</div>
<div id="BarraCarrega"><div id="BarraPercento"></div></div>
</div><!-- CentroFormConect2 -->
<input type="submit" class="BnteditCad2" value="ENVIAR" />
<input type="button" class="BnteditCad3" value="CANCELAR" />
</form>
<!--////////////////////////////////////////////////////////////////////////////////////////////////////-->

