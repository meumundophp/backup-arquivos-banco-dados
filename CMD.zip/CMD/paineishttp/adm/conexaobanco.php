﻿<script type="text/javascript">
$(window).ready(function(){
//chama opções da base de dados										  														  
confPainelBanco();
//fecha painel
//ClosehttpPaineis(".BnteditCad");

});//ready
</script>


<div id="CampNomePadrao">
<div class="imgNomePg" id="imgNomePg2"></div>
<p class="TxtNomePg">CONEXÃO DO BANCO DE DADOS</p>
<div id="rodapeinvisivel"></div>
</div><!--CampNomePadrao-->

<div id="Mgg_sitema"><?php echo @$Msg_List; ?></div>

<form enctype="multipart/form-data" id="ConectBanco">
<div id="CentroFormConect">
<div id="txt_1" class="nomeCampTxt">Servidor</div><!-- nomeCampTxt -->
<input id="val_1" type="text" class="TxtIput" value="<?php echo @$servidor;?>" / >
<div id="txt_2" class="nomeCampTxt">Usuário</div><!-- nomeCampTxt -->
<input id="val_2" type="text" class="TxtIput" value="<?php echo @$usuario;?>" />
<div id="txt_3" class="nomeCampTxt">Banco</div><!-- nomeCampTxt -->
<input id="val_3" type="text" class="TxtIput" value="<?php echo @$banco;?>" />
<div id="txt_4" class="nomeCampTxt">Senha</div><!-- nomeCampTxt -->
<input id="val_4" type="password" class="TxtIput" value="<?php echo @$senha;?>" />
<div id="painel_enviacao"></div><!-- painel_enviacao -->
</div><!-- CentroFormConect -->
<input type="submit" class="BnteditCad2" value="CONECTAR" />


</form>