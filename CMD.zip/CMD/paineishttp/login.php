﻿<?php //permições
if(@$_SESSION['cmd']['cod']!=""){//caso estege logado
$nomePg="". @$_SESSION['cmd']['nome'];
$loginLog="false";
}else{//caso não esteja logado-------------------------------------------
$nomePg="LOGIN DE ACESSO";
$loginLog="true";
}//else
?>
<script type="text/javascript">
$(window).ready(function(){
//chama opções da base de dados										  														  
efetivandoLogin();
});//ready
</script>
<div id="CampNomePadrao">
<div class="imgNomePg" id="imgNomePg3"></div>
<p class="TxtNomePg"><?php echo @$nomePg; ?></p>
<div id="rodapeinvisivel"></div>
</div><!--CampNomePadrao-->

<?php if(@$loginLog=="false"){?>
<div id="BntSairConta">
<a href="operacao/sair_conta.php" target="_self" id="BntSairContaLink">- Sair dessa conta</a>
</div><?php } ?>


<?php if(@$loginLog=="true"){?>
<form enctype="multipart/form-data" id="LoginCMD">
<div id="CentroFormConect">
<div id="txt_1" class="nomeCampTxt">Login</div><!-- nomeCampTxt -->
<input id="val_1" type="text" class="TxtIput" value="" />
<div id="txt_2" class="nomeCampTxt">Senha de acesso</div><!-- nomeCampTxt -->
<input id="val_2" type="password" class="TxtIput" value="" />
<div id="painel_enviacao"></div><!-- painel_enviacao -->
</div><!-- CentroFormConect -->
<input type="submit" class="BnteditCad2" value="LOGAR" />
</form><?php } ?>