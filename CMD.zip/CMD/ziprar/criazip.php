﻿<?php 
//criar um ficheiro ZIP 
function create_zip($files = array(),$destination = '',$overwrite = false) {
    //Se o ficheiro existe, e overwrite é falso, return false
    if(file_exists($destination) && !$overwrite) { return false; }
    //variaveis
    $valid_files = array();
    //Se foi dado os files...
    if(is_array($files)) {
        //ciclo por cada ficheiro
        foreach($files as $file) {
            //certificar se ficheiro existe mesmo
            if(file_exists($file)) {
                $valid_files[] = $file;
            }
        }
    }
    //se temos então bons ficheiros...
    if(count($valid_files)) {
        //criar o arquivo ZIP
        $zip = new ZipArchive();
        if($zip->open($destination,$overwrite ? ZIPARCHIVE::OVERWRITE : ZIPARCHIVE::CREATE) !== true) {
            return false;
        }
        //adicionar os ditos finheiros
        foreach($valid_files as $file) {
            $zip->addFile($file,$file);
        }
        //debug
        //echo 'O arquivo ZIP contem ',$zip->numFiles,' files com o estado de ',$zip->status;
 
        //fechar o zip -- done!
        $zip->close();
 
        //verificar se o ZIP foi bem criado
        return file_exists($destination);
    }
    else
    {
        return false;
    }
}//funcao zipa




function extrairZip($localArquivo,$localExtrair){

$nomedoarquivozip=$localArquivo;
$zip = new ZipArchive;
if ($zip->open($nomedoarquivozip) === TRUE) {
$zip->extractTo($localExtrair); $zip->close(); $retur='true';} else {$retur='false';}
return $retur;}//deszipa

?>